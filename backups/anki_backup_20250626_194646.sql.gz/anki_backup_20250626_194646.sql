-- MySQL dump 10.13  Distrib 9.3.0, for macos15.2 (arm64)
--
-- Host: localhost    Database: anki
-- ------------------------------------------------------
-- Server version	9.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('f3f061e2f9cc');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cards`
--

DROP TABLE IF EXISTS `cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '知识点',
  `answer` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '答案',
  `review_count` int NOT NULL COMMENT '复习次数',
  `first_review_at` datetime DEFAULT NULL COMMENT '首次复习时间',
  `next_review_at` datetime NOT NULL COMMENT '下次复习时间',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `user_id` int NOT NULL COMMENT '所属用户ID',
  PRIMARY KEY (`id`),
  KEY `ix_cards_id` (`id`),
  KEY `ix_cards_next_review_at` (`next_review_at`),
  KEY `ix_cards_question` (`question`),
  KEY `ix_cards_user_id` (`user_id`),
  CONSTRAINT `cards_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cards`
--

LOCK TABLES `cards` WRITE;
/*!40000 ALTER TABLE `cards` DISABLE KEYS */;
INSERT INTO `cards` VALUES (14,'发水电费第三方233','维尔维尔',0,'2025-06-20 23:49:07','2025-06-20 23:49:07','2025-06-14 18:38:11','2025-06-20 23:49:07',1),(16,'发大水发大水we','热热',1,'2025-06-18 23:44:39','2025-06-19 23:44:39','2025-06-14 21:13:01','2025-06-18 23:44:39',1),(19,'长文本3332228245','长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本长文本',0,NULL,'2025-05-28 16:00:00','2025-06-19 19:46:02','2025-06-20 23:53:51',1),(21,'是的额外呃呃呃日f','神鼎飞丹砂',1,'2025-06-20 23:48:39','2025-06-20 16:00:00','2025-06-19 21:51:26','2025-06-20 23:48:51',1),(22,'羊子','狗子',1,'2025-06-20 23:47:56','2025-07-17 16:00:00','2025-06-20 23:47:32','2025-06-20 23:48:15',1),(25,'四大分卫额范围','维尔维尔',0,NULL,'2025-06-24 00:00:00','2025-06-21 18:07:49','2025-06-22 10:34:07',2),(26,'胜多负少顶峰 2345','2323223',1,'2025-06-21 21:06:01','2025-06-25 00:00:00','2025-06-21 18:21:46','2025-06-25 18:39:25',2),(35,'12胜多负少顶峰','额外热污染',1,'2025-06-25 21:41:00','2025-06-26 21:41:00','2025-06-22 19:17:23','2025-06-25 21:41:00',6),(36,'543245','爱你哦',1,'2025-06-25 18:47:37','2025-06-26 18:47:37','2025-06-22 20:46:16','2025-06-25 18:47:37',6),(37,'成绩','艾灸',1,'2025-06-25 21:13:56','2025-06-25 00:00:00','2025-06-22 20:56:11','2025-06-25 21:14:02',6),(38,'梦里水乡','梦里水乡',0,NULL,'2025-06-22 21:08:31','2025-06-22 21:08:31','2025-06-22 21:08:31',7),(39,'文额额问题','为二位二位',0,NULL,'2025-06-25 21:48:27','2025-06-25 21:48:27','2025-06-25 21:48:27',6),(40,'额儿童w','为二位',1,'2025-06-25 21:49:00','2025-06-26 21:49:00','2025-06-25 21:48:37','2025-06-25 21:49:00',6),(41,'i一u有',' 98797',1,'2025-06-25 21:50:53','2025-06-26 21:50:53','2025-06-25 21:50:29','2025-06-25 21:50:53',6),(42,'爻','很快观看',0,NULL,'2025-06-25 21:51:42','2025-06-25 21:51:42','2025-06-25 21:51:42',6),(43,'111','222',0,NULL,'2025-06-25 22:14:08','2025-06-25 22:14:08','2025-06-25 22:14:08',6),(44,'333','333',0,NULL,'2025-06-25 22:17:31','2025-06-25 22:17:31','2025-06-25 22:17:31',6),(45,'123321','1111',0,NULL,'2025-06-25 22:21:36','2025-06-25 22:21:36','2025-06-25 22:21:36',6),(46,'4444','4444',0,NULL,'2025-06-25 22:25:27','2025-06-25 22:25:27','2025-06-25 22:25:27',6);
/*!40000 ALTER TABLE `cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_rules`
--

DROP TABLE IF EXISTS `review_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `review_count` int NOT NULL,
  `interval_days` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int NOT NULL COMMENT '所属用户ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_review_count` (`user_id`,`review_count`),
  KEY `ix_review_rules_id` (`id`),
  KEY `ix_review_rules_user_id` (`user_id`),
  KEY `ix_review_rules_review_count` (`review_count`),
  CONSTRAINT `review_rules_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_rules`
--

LOCK TABLES `review_rules` WRITE;
/*!40000 ALTER TABLE `review_rules` DISABLE KEYS */;
INSERT INTO `review_rules` VALUES (23,1,1,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(24,2,1,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(25,3,1,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(26,4,2,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(27,5,3,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(28,6,5,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(29,7,7,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(30,8,7,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(31,9,14,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(32,10,14,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(33,11,30,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(34,12,30,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(35,13,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(36,14,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(37,15,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(38,16,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(39,17,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(40,18,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(41,19,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(42,20,60,'2025-06-22 13:04:50','2025-06-22 13:04:50',5),(43,1,1,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(44,2,1,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(45,3,1,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(46,4,2,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(47,5,3,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(48,6,5,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(49,7,7,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(50,8,7,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(51,9,14,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(52,10,14,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(53,11,30,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(54,12,30,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(55,13,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(56,14,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(57,15,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(58,16,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(59,17,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(60,18,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(61,19,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(62,20,60,'2025-06-22 13:13:00','2025-06-22 13:13:00',2),(63,1,1,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(64,2,1,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(65,3,1,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(66,4,2,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(67,5,3,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(68,6,5,'2025-06-22 17:05:22','2025-06-22 17:05:22',1),(69,7,7,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(70,8,7,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(71,9,14,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(72,10,14,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(73,11,30,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(74,12,30,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(75,13,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(76,14,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(77,15,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(78,16,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(79,17,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(80,18,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(81,19,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(82,20,60,'2025-06-22 17:05:23','2025-06-22 17:05:23',1),(83,1,1,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(84,2,1,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(85,3,1,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(86,4,2,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(87,5,3,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(88,6,5,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(89,7,7,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(90,8,7,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(91,9,14,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(92,10,14,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(93,11,30,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(94,12,30,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(95,13,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(96,14,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(97,15,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(98,16,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(99,17,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(100,18,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(101,19,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(102,20,60,'2025-06-22 18:52:48','2025-06-22 18:52:48',6),(103,1,1,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(104,2,1,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(105,3,1,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(106,4,2,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(107,5,3,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(108,6,5,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(109,7,7,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(110,8,7,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(111,9,14,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(112,10,14,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(113,11,30,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(114,12,30,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(115,13,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(116,14,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(117,15,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(118,16,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(119,17,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(120,18,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(121,19,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7),(122,20,60,'2025-06-22 21:07:59','2025-06-22 21:07:59',7);
/*!40000 ALTER TABLE `review_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review_settings`
--

DROP TABLE IF EXISTS `review_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `review_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `review_count` int NOT NULL COMMENT '复习次数',
  `interval_days` int NOT NULL COMMENT '间隔天数',
  `description` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设置描述',
  `is_active` tinyint(1) NOT NULL COMMENT '是否启用',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_review_settings_id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review_settings`
--

LOCK TABLES `review_settings` WRITE;
/*!40000 ALTER TABLE `review_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `review_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openid` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `nickname` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_users_openid` (`openid`),
  KEY `ix_users_id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'test-openid','2025-06-14 07:53:31','2025-06-14 07:53:31',NULL,NULL,NULL),(2,'h5-test-openid','2025-06-21 17:41:51','2025-06-21 17:41:51',1,'测试用户',''),(3,'test-new-user-openid','2025-06-22 12:59:33','2025-06-22 12:59:33',1,'新测试用户',''),(4,'test-new-user-openid-811a7d69-b29d-49ea-9f95-50bcc8327dca','2025-06-22 13:03:33','2025-06-22 13:03:33',1,'新测试用户',''),(5,'test-new-user-openid-70f13166-7cd6-4771-9b3d-ff8185af609e','2025-06-22 13:04:51','2025-06-22 13:04:51',1,'新测试用户',''),(6,'o3ngB7pASuCkpeWHEn0xoltWW488','2025-06-22 18:52:48','2025-06-22 18:52:48',1,'微信用户',''),(7,'o3ngB7sayFRlK6g_SDRuZBJ2j-Xc','2025-06-22 21:08:00','2025-06-22 21:08:00',1,'微信用户','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'anki'
--

--
-- Dumping routines for database 'anki'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-26 19:46:47
